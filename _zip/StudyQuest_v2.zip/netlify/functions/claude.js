// v4 - debug + lowercase headers
const https = require('https');

exports.handler = async (event) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, X-Api-Key, x-api-key',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: cors, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: cors, body: 'Method Not Allowed' };
  }

  // Netlify lowercases all headers
  const allHeaders = event.headers || {};
  const apiKey = allHeaders['x-api-key'] || allHeaders['X-Api-Key'] || allHeaders['x-api-key'.toLowerCase()];

  console.log('Headers recibidos:', Object.keys(allHeaders).join(', '));
  console.log('API Key presente:', !!apiKey);
  console.log('Body length:', (event.body || '').length);

  if (!apiKey) {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ error: { message: 'Falta API Key en headers' } })
    };
  }

  const bodyData = event.body || '';

  return new Promise((resolve) => {
    const options = {
      hostname: 'api.anthropic.com',
      path: '/v1/messages',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(bodyData),
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log('Anthropic status:', res.statusCode);
        console.log('Anthropic response preview:', data.slice(0, 200));
        resolve({
          statusCode: res.statusCode,
          headers: { ...cors, 'Content-Type': 'application/json' },
          body: data,
        });
      });
    });

    req.on('error', (err) => {
      console.error('Request error:', err.message);
      resolve({
        statusCode: 500,
        headers: { ...cors, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: { message: err.message } }),
      });
    });

    req.write(bodyData);
    req.end();
  });
};